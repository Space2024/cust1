"use client";
import Customer_connect from './root';

export default function App() {
  return (
    <main>
      <section>
        <Customer_connect />
      </section>
    </main>
  );
}
