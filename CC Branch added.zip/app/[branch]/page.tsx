"use client";
import Customer_connect from './connect';

export default function App() {
  return (
    <main>
      <section>
        <Customer_connect />
      </section>
    </main>
  );
}
